res_fpath = 'D:\Python Program\MVDet\logs\wildtrack_frame\default\原版DCN_test3\test_epoch3.txt';
gt_fpath = 'D:\Python Program\MVDet\multiview_detector\evaluation\gt-demo.txt';

evaluateDetection(res_fpath, gt_fpath, 'wildtrack');