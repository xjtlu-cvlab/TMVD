import numpy as np
import matlab.engine
from multiview_detector.evaluation.pyeval.evaluateDetection import evaluateDetection_py


def matlab_eval(res_fpath, gt_fpath, dataset='wildtrack'):
    eng = matlab.engine.start_matlab()
    eng.cd('multiview_detector/evaluation/motchallenge-devkit')
    res = eng.evaluateDetection(res_fpath, gt_fpath, dataset)
    recall, precision, moda, modp = np.array(res['detMets']).squeeze()[[0, 1, -2, -1]]
    return recall, precision, moda, modp


def python_eval(res_fpath, gt_fpath, dataset='wildtrack'):
    modp, moda, recall, precision = evaluateDetection_py(res_fpath, gt_fpath, dataset)
    return recall, precision, moda, modp
