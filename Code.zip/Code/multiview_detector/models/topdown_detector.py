import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from multiview_detector.models.resnet import resnet18
import torchvision
import copy


class TopDownDetector(nn.Module):
    def __init__(self, dataset, arch='resnet18'):
        super().__init__()
        self.cudas = 'cuda:0'
        self.num_cam = dataset.num_cam
        self.img_shape, self.reducedgrid_shape = dataset.img_shape, dataset.reducedgrid_shape
        self.visual = False
        self.pratio = 3
        self.disthresh = dataset.base.unit
        self.channels = 8192
        self.channels2 = 1024

        self.bbox_by_pos_cam = dataset.base.read_pom()
        self.get_worldgrid_from_pos = dataset.base.get_worldgrid_from_pos
        self.get_worldcoord_from_pos = dataset.base.get_worldcoord_from_pos
        self.coord_map = self.create_coord_map(self.reducedgrid_shape + [1])
        # img
        self.upsample_shape = list(map(lambda x: int(x / dataset.img_reduce), self.img_shape))

        poslist = np.loadtxt('./wildtrack_poslist_25.0cm.txt')
        poslist = poslist.tolist()
        self.posid_list = poslist
        points1 = []

        for posID in self.posid_list:
            coordw = self.get_worldcoord_from_pos(posID)
            points1.append([coordw[1], coordw[0]])
        self.points1 = torch.Tensor(points1)

        gtlist = np.loadtxt('./wildtrack_gtpos.txt')
        gtlist = gtlist.tolist()
        self.gtlist = gtlist

        if arch == 'resnet18':
            base = nn.Sequential(*list(resnet18(replace_stride_with_dilation=[False, True, True]).children())[:-2])
            self.base_pt = base.to(self.cudas)
            out_channel = 512
        else:
            raise Exception('architecture currently support [resnet18]')

        self.map_classifier = nn.Sequential(nn.Conv2d(self.channels, 32, 3, padding=1), nn.ReLU(),
                                            nn.Conv2d(32, 32, 3, padding=2, dilation=2), nn.ReLU(),
                                            nn.Conv2d(32, 1, 3, padding=4, dilation=4, bias=False)).to(self.cudas)
        self.weights = nn.Sequential(nn.Flatten(0), nn.Linear(self.channels, 512), nn.ReLU(), nn.Linear(512, 64),
                                     nn.ReLU(), nn.Linear(64, 1)).to(self.cudas)
        self.downsample = nn.Sequential(nn.Conv2d(out_channel, 32, 1)).to(self.cudas)
        pass

    def forward(self, imgs, frame = None):
        B, N, C, H, W = imgs.shape
        assert N == self.num_cam
        world_features = []
        world_feature_topdown = torch.zeros([1, self.channels, 120, 360]).to(self.cudas)

        posid = copy.deepcopy(self.posid_list)
        gtpoints = []
        idlist = []

        if frame is not None:
            for i in range(len(self.gtlist)):
                if self.gtlist[i][0] == frame:
                    coordgt = self.get_worldcoord_from_pos(self.gtlist[i][1])
                    gtpoints.append([coordgt[1], coordgt[0]])
            gtpoints = torch.Tensor(gtpoints)
            dist = self.points_distance(self.points1, gtpoints)
            dist_max = torch.min(dist, dim=1)[0]
            positive = dist_max < self.disthresh
            positive_indices = torch.nonzero(positive)[:, 0]
            negative = dist_max >= self.disthresh
            negative_indices = torch.nonzero(negative)[:, 0]
            rand_idx = torch.randperm(negative_indices.size()[0])
            positive_count = positive_indices.size()[0]
            negative_count = int(self.pratio * positive_count - positive_count)
            rand_idx = rand_idx[:negative_count]
            rand_idx = rand_idx.cuda()
            negative_indices = negative_indices[rand_idx]
            for inx in positive_indices.cpu().numpy():
                idlist.append(posid[inx])
            for inx in negative_indices.cpu().numpy():
                idlist.append(posid[inx])
            posid = idlist

        tx = []
        ty = []
        ttf1 = []

        imgsf = []
        for cam in range(self.num_cam):
            img_feature = self.base_pt(imgs[:, cam].to(self.cudas))
            img_feature = F.interpolate(img_feature, self.upsample_shape, mode='bilinear', align_corners=True)
            img_feature = self.downsample(img_feature)
            imgsf.append(img_feature)

        for posID in posid:
            regionst = torch.zeros([1, self.channels]).to(self.cudas)
            for cam in range(len(imgsf)):
                bbox = copy.deepcopy(self.bbox_by_pos_cam[posID][cam])
                if bbox is not None:
                    bbox[0] = bbox[0] // 4
                    bbox[1] = bbox[1] // 4
                    bbox[2] = bbox[2] // 4
                    bbox[3] = bbox[3] // 4

                    bbox = torch.tensor(np.array(bbox).astype(np.float32))
                    coords = torch.cat((torch.Tensor([0]), torch.Tensor(bbox))).view(1, 5).cuda()
                    regions = torchvision.ops.roi_align(imgsf[cam], coords, output_size=(16, 16))
                    regions = regions.view([regions.size()[0], -1])
                    weights = self.weights(regions)
                    regions = weights * regions

                    regionst.add_(regions)

            coordgrid = self.get_worldgrid_from_pos(posID)
            coordgrid[0] = coordgrid[0] // 4
            coordgrid[1] = coordgrid[1] // 4

            tx.append(coordgrid[0])
            ty.append(coordgrid[1])
            ttf1.append(regionst)
        ttf1 = torch.stack(ttf1, dim=2)
        world_feature_topdown[:, :, tx, ty] = ttf1

        world_features.append(world_feature_topdown)
        world_features = torch.cat(world_features, dim=1)
        map_result = self.map_classifier(world_features.to(self.cudas))
        map_result = F.interpolate(map_result, self.reducedgrid_shape, mode='bilinear')
        return map_result

    def points_distance(self, points1, points2):
        """Computes IoU overlaps between two sets of boxes.
        points1, points2: [N, (y1, x1)].
        """
        # 1. Tile points2 and repeate points1. This allows us to compare
        # every boxes1 against every points2 without loops.
        # TF doesn't have an equivalent to np.repeate() so simulate it
        # using tf.tile() and tf.reshape.
        points1_repeat = points2.size()[0]
        points2_repeat = points1.size()[0]
        points1 = points1.repeat(1, points1_repeat).view(-1, 2)
        points2 = points2.repeat(points2_repeat, 1)

        # 2. Compute distance
        p1_y1, p1_x1 = points1.chunk(2, dim=1)
        p2_y1, p2_x1 = points2.chunk(2, dim=1)
        ys = p1_y1 - p2_y1
        xs = p1_x1 - p2_x1
        l2 = torch.sqrt(ys * ys + xs * xs)
        distances = l2.view(points2_repeat, points1_repeat)
        return distances

    def create_coord_map(self, img_size, with_r=False):
        H, W, C = img_size
        grid_x, grid_y = np.meshgrid(np.arange(W), np.arange(H))
        grid_x = torch.from_numpy(grid_x / (W - 1) * 2 - 1).float()
        grid_y = torch.from_numpy(grid_y / (H - 1) * 2 - 1).float()
        ret = torch.stack([grid_x, grid_y], dim=0).unsqueeze(0)
        if with_r:
            rr = torch.sqrt(torch.pow(grid_x, 2) + torch.pow(grid_y, 2)).view([1, 1, H, W])
            ret = torch.cat([ret, rr], dim=1)
        return ret

