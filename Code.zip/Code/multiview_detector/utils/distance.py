import torch
from torch.autograd import Variable
import numpy as np
def bbox_overlaps(points1, points2):
    """Computes IoU overlaps between two sets of boxes.
    boxes1, boxes2: [N, (y1, x1)].
    """
    # 1. Tile points2 and repeate points1. This allows us to compare
    # every boxes1 against every points2 without loops.
    # TF doesn't have an equivalent to np.repeate() so simulate it
    # using tf.tile() and tf.reshape.
    points1_repeat = points2.size()[0]
    points2_repeat = points1.size()[0]
    points1 = points1.repeat(1,points1_repeat).view(-1,2)
    points2 = points2.repeat(points2_repeat,1)

    # 2. Compute distance
    p1_y1, p1_x1 = points1.chunk(2, dim=1)
    p2_y1, p2_x1 = points2.chunk(2, dim=1)
    ys = p1_y1 - p2_y1
    xs = p1_x1 - p2_x1
    l2 = torch.sqrt(ys*ys + xs*xs)

    distances = l2.view(points2_repeat, points1_repeat)

    return distances

boxes1 = []
for i in range(3):
    box1 = [1+i,2+i]
    boxes1.append(box1)
    # boxes1 = torch.stack([box1[:,0],box1[:,1],box1[:,2],box1[:,3]], dim=1)
boxes1 =torch.Tensor(boxes1)
box2 = [[1,1.5], [3,5]]
box2 = torch.Tensor(box2)
print('boxes1: ', boxes1)
print()
output = bbox_overlaps(boxes1, box2)
iou_max = torch.min(output, dim=1)[0]
positive = iou_max < 2
negative = iou_max > 2
print('negative: ', negative)
positive_indices = torch.nonzero(positive)[:, 0]

rand_idx = torch.randperm(positive_indices.size()[0])

positive_overlaps = output[positive_indices.data,:]
value = positive_overlaps.cpu().numpy()
print(output)
print(iou_max)
print(positive)
print(rand_idx.cpu().numpy())
for i in range(len(value[:,0])):
    print(value[:,0][i])

gtlist = np.loadtxt('E:/python program/MVDet/gtpos.txt')
gtlist = gtlist.tolist()
print('gt: ', gtlist[2][1])

