import numpy as np

def get_worldcoord_from_imagecoord(image_coord, intrinsic_mat, extrinsic_mat):
    project_mat = intrinsic_mat @ extrinsic_mat
    project_mat = np.linalg.inv(np.delete(project_mat, 2, 1))
    image_coord = np.concatenate([image_coord, np.ones([1, image_coord.shape[1]])], axis=0)
    world_coord = project_mat @ image_coord
    world_coord = world_coord[:2, :] / world_coord[2, :]
    return world_coord

def get_imagecoord_from_worldcoord(world_coord, intrinsic_mat, extrinsic_mat, height):
    project_mat = intrinsic_mat @ extrinsic_mat
    # project_mat = np.delete(project_mat, 2, 1)
    test = [[height]] * world_coord.shape[1]
    test = np.array(test)
    test = test.reshape(1, world_coord.shape[1])

    world_coord = np.concatenate([world_coord, test], axis=0)
    world_coord = np.concatenate([world_coord, np.ones([1, world_coord.shape[1]])], axis=0) #Xw Yw Zw 1
    image_coord = project_mat @ world_coord
    image_coord = image_coord[:2, :] / image_coord[2, :]
    return image_coord
